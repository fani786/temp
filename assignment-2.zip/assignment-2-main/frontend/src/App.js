// src/App.js
import React, { useState, useEffect } from 'react';
import './App.css';
import ContactForm from './components/ContactForm';
import ContactList from './components/ContactList';
import StatsView from './components/StatsView';

function App() {
  const [contacts, setContacts] = useState([]);
  const [showStats, setShowStats] = useState(false);

  useEffect(() => {
    // Fetch contacts from the API when the component mounts
    const fetchContacts = async () => {
      try {
        const response = await fetch('http://localhost/api/contacts');
        if (response.ok) {
          const data = await response.json();
          setContacts(data);
        } else {
          console.error('Failed to fetch contacts from the API.');
        }
      } catch (error) {
        console.error('An error occurred while fetching contacts:', error);
      }
    };

    fetchContacts();
  }, []);
  
    const toggleStats = () => {
    setShowStats(!showStats); // Toggle the StatsView visibility
  };

  const addContact = (contact) => {
    setContacts([...contacts, contact]);
  };

  const deleteContact = async (id) => {
    try {
      // Send a DELETE request to the API with the contactId
      const response = await fetch(`http://localhost/api/contacts/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        // If the delete request was successful, update the contacts state
        setContacts(contacts.filter((contact) => contact.id !== id));
        console.log('Contact deleted successfully.');
      } else {
        console.error('Failed to delete contact from the API.');
      }
    } catch (error) {
      console.error('An error occurred while sending the DELETE request:', error);
    }
  };
  
  const refreshContacts = async () => {
  try {
    const response = await fetch('http://localhost/api/contacts');
    if (response.ok) {
      const data = await response.json();
      setContacts(data);
    } else {
      console.error('Failed to fetch contacts from the API.');
    }
  } catch (error) {
    console.error('An error occurred while fetching contacts:', error);
  }
};
  
  

  return (
   <div className="App tables-container">
  <h1 className="contact-title">Contact-Manager</h1>
  <ContactForm onAddContact={addContact} refreshContacts={refreshContacts}/>
  <ContactList contacts={contacts} onDeleteContact={deleteContact} onAddContact={addContact} />

  <div className="contact-title">
    <p className="text-link">
      <p className="text-link1">Click on a contact to view phone numbers</p>
    </p>
    <p>
      <p className="text-link1" onClick={toggleStats}>
        {showStats ? 'Hide Stats' : 'View Stats'}
      </p>
    </p>
    {showStats && <StatsView onClose={toggleStats} />}
  </div>
</div>
  );
}

export default App;
