// StatsView.js
import React, { useState, useEffect } from 'react';

function StatsView({ onClose }) {
  const [statsData, setStatsData] = useState(null);

  useEffect(() => {
    // Fetch statistics data from your API when the component mounts
    const fetchStats = async () => {
      try {
        const response = await fetch('http://localhost/api/stats'); // Replace with your API endpoint
        if (response.ok) {
          const data = await response.json();
          setStatsData(data);
        } else {
          console.error('Failed to fetch statistics from the API.');
        }
      } catch (error) {
        console.error('An error occurred while fetching statistics:', error);
      }
    };

    fetchStats();
  }, []);

  return (
    <div className="stats-container">
      <h2>Statistics</h2>
      {statsData ? (
        <div>
          <h3>Total Contacts: </h3> <p> {statsData.totalContacts}</p>
          <h3>Total Phones: </h3> <p> {statsData.totalPhones}</p>
          <h3>Newest Contact Timestamp: </h3> <p> {statsData.newestTimestamp}</p>
          <h3>Oldest Contact Timestamp: </h3> <p> {statsData.oldestTimestamp}</p>
        </div>
      ) : (
        <p>Loading statistics...</p>
      )}
      <button onClick={onClose}>Close</button>
    </div>
  );
}

export default StatsView;
