// src/components/PhoneNumberForm.js
import React, { useState } from 'react';

function PhoneNumberForm({ onAddPhoneNumber }) {
  const [contactType, setContactType] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  const handleTypeChange = (e) => {
    setContactType(e.target.value);
  };

  const handlePhoneChange = (e) => {
    setPhoneNumber(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddPhoneNumber({ type: contactType, phone: phoneNumber });
    setContactType('');
    setPhoneNumber('');
  };

  return (
    <div>
      <h2>Add Phone Number</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Contact Type:
          <input
            type="text"
            value={contactType}
            onChange={handleTypeChange}
            placeholder="Enter contact type"
          />
        </label>
        <label>
          Phone Number:
          <input
            type="text"
            value={phoneNumber}
            onChange={handlePhoneChange}
            placeholder="Enter phone number"
          />
        </label>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default PhoneNumberForm;
