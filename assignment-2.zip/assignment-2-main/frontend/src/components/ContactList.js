import React, { useState, useEffect } from 'react';

function ContactList({ contacts, onDeleteContact, onAddContact}) {
  const [subTableData, setSubTableData] = useState({});
  const [expandedContacts, setExpandedContacts] = useState({});
  const [formDatas, setFormDatas] = useState({}); // Store form data for each contact

  const handleInputChange = (e, contactId) => {
    const { name, value } = e.target;
    // Update the form data for the specific contact
    setFormDatas((prevFormDatas) => ({
      ...prevFormDatas,
      [contactId]: { ...prevFormDatas[contactId], [name]: value },
    }));
  };


	const fetchAndRefreshPhones = async (contactId) => {
  try {
    const response = await fetch(`http://localhost/api/contacts/${contactId}/phones/`);
    if (response.ok) {
      const data = await response.json();

      // Update the subTableData state for the specific contact ID
      setSubTableData((prevState) => ({
        ...prevState,
        [contactId]: data,
      }));
    } else {
      console.error('Failed to fetch phone data for the contact from the API.');
    }
  } catch (error) {
    console.error('An error occurred while fetching phone data:', error);
  }
};
	
  const handleFormSubmit = async (e, contactId) => {
    e.preventDefault();
    try {
      const response = await fetch(`http://localhost/api/contacts/${contactId}/phones`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formDatas[contactId]), // Use form data for the specific contact
      });

      if (response.ok) {
        // Handle success, e.g., update the sub-table data if needed
		  // Refresh the phones data for the specific contact ID
		        setFormDatas({ type: '', phoneNumber: '' });
      fetchAndRefreshPhones(contactId);

      // Clear the form inputs

        console.log('Form submitted successfully for contact ID:', contactId);
      } else {
        console.error('Failed to submit the form for contact ID:', contactId);
      }
    } catch (error) {
      console.error('An error occurred while submitting the form:', error);
    }
  };

  useEffect(() => {
    // Fetch sub-table data for each contact when the component mounts
    contacts.forEach((contact) => {
      fetchSubTableData(contact.id);
    });
  }, [contacts]);
  
  const onDeleteSubTableRow = async (contactId, phoneId) => {
    try {
      const response = await fetch(
        `http://localhost/api/contacts/${contactId}/phones/${phoneId}`,
        {
          method: 'DELETE',
        }
      );

      if (response.ok) {
        // If the delete request was successful, update the sub-table data
        // Remove the deleted phone number from subTableData
        setSubTableData((prevState) => ({
          ...prevState,
          [contactId]: prevState[contactId].filter(
            (data) => data.id !== phoneId
          ),
        }));
        console.log('Phone number deleted successfully.');
      } else {
        console.error('Failed to delete phone number.');
      }
    } catch (error) {
      console.error('An error occurred while sending the DELETE request:', error);
    }
  };

  // Function to fetch sub-table data for a specific contact
  const fetchSubTableData = async (contactId) => {
    try {
      const response = await fetch(`http://localhost/api/contacts/${contactId}/phones/`);
      if (response.ok) {
        const data = await response.json();
        // Update subTableData state with the fetched data
        setSubTableData((prevState) => ({
          ...prevState,
          [contactId]: data,
        }));
      } else {
        console.error('Failed to fetch sub-table data from the API.');
      }
    } catch (error) {
      console.error('An error occurred while fetching sub-table data:', error);
    }
  };

  // Function to toggle the expansion of sub-table for a contact
  const toggleExpansion = (contactId) => {
    setExpandedContacts((prevExpandedContacts) => ({
      ...prevExpandedContacts,
      [contactId]: !prevExpandedContacts[contactId], // Toggle the expanded state
    }));
  };

  return (
    <div>
      {contacts.map((contact) => (
        <div key={contact.id} className="contact-card">
          <table className="contact-main">
            <thead>
              <tr>
                <th>
                  <div
                    className="contact-name"
                    onClick={() => toggleExpansion(contact.id)} // Toggle expansion on click
                  >
                    {contact.contactName}
                  </div>
                </th>
                <th className="ctbut">
                  <button onClick={() => onDeleteContact(contact.id)}>
                    Delete
                  </button>
                </th>
              </tr>
            </thead>
          </table>
          {/* Display sub-table if contact is expanded */}
          {expandedContacts[contact.id] && (
            <>
              <form
                className="input-form"
                onSubmit={(e) => handleFormSubmit(e, contact.id)}
              >
                <input
                  type="text"
                  name="type"
                  placeholder="Type"
                  value={formDatas[contact.id]?.type || ''}
                  onChange={(e) => handleInputChange(e, contact.id)}
                />
                <input
                  type="text"
                  name="phoneNumber"
                  placeholder="Phone Number"
                  value={formDatas[contact.id]?.phoneNumber || ''}
                  onChange={(e) => handleInputChange(e, contact.id)}
                />
                <button type="submit">Submit</button>
              </form>
              <table className="contact-table">
                <thead>
                  <tr>
                    <th>Type</th>
                    <th>Phone Number</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {Array.isArray(subTableData[contact.id]) &&
                    subTableData[contact.id].map((data) => (
                      <tr key={data.id}>
                        <td>{data.type}</td>
                        <td>{data.phoneNumber}</td>
                        <td>
                          <button
                           onClick={() =>
                              onDeleteSubTableRow(contact.id, data.id)
                            }
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </>
          )}
        </div>
      ))}
	 
    </div>
  );
}

export default ContactList;
