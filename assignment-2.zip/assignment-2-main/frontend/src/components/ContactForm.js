// src/components/ContactForm.js
import React, { useState } from 'react';
import contactBookLogo from './contact-book.png'; // Update the path to your image file


function ContactForm({ onAddContact, refreshContacts }) {
  const [contactName, setContactName] = useState('');

  const handleNameChange = (e) => {
    setContactName(e.target.value);
  };

  // src/components/ContactForm.js
// ...

const handleSubmit = async (e) => {
  e.preventDefault();

  try {
    const contactData = { contactName };

    const response = await fetch('http://localhost/api/contacts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(contactData),
    });

    if (response.ok) {
		setContactName('');
      // Call the parent component's onAddContact function to refresh the contact list
      onAddContact(contactData);
	  
	  refreshContacts();
		//setContacts(data);
      console.log('Contact successfully added to the API.');

      // Trigger a refresh of the contact list by updating the contacts state
      refreshContacts();

      // Clear the input field
      setContactName('');
    } else {
      console.error('Failed to add contact to the API.');
    }
  } catch (error) {
    console.error('An error occurred while sending the POST request:', error);
  }
};

// ...


  return (
  // Inside your ContactForm component's JSX


   <form onSubmit={handleSubmit}>
   <div className="logo-container">
  <img src={contactBookLogo} alt="Contact Book Logo" className="contact-book-logo" />
</div>
  <div className="form-group maininput">
   
      <input 
		type="text"
        value={contactName}
        onChange={handleNameChange}
        placeholder="Enter contact name"
      />
   
  </div>
  <div className="form-group mainbutton">
    <button type="submit">Submit</button>
  </div>
</form>

  );
}

export default ContactForm;
