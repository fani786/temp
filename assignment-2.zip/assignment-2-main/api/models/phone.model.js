module.exports = (sequelize, Sequelize) => {
  const Phone = sequelize.define("phone", {
    id: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    type: {
      type: Sequelize.STRING, // Use Sequelize.STRING for VARCHAR
    },
    phoneNumber: {
      type: Sequelize.STRING, // Use Sequelize.STRING for VARCHAR
    },
    // Add other columns as needed
  });

  return Phone;
};
