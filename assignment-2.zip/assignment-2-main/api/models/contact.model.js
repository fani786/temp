module.exports = (sequelize, Sequelize) => {
    const Contact = sequelize.define("contact", {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
		contactName: {
			type: Sequelize.STRING, // Use Sequelize.STRING for VARCHAR
		},
        // DEFINE YOUR MODEL HERE
    });
  
    return Contact;
};