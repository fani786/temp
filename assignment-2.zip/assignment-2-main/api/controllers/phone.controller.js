const db = require("../models");
const Phones = db.phones;
const Op = db.Sequelize.Op;

// Create phone
exports.create = (req, res) => {
  const contactId = req.params.contactId;
  const { type, phoneNumber } = req.body;

  // Validate the data, e.g., check if required fields are provided (type and phoneNumber)

  // Check if the phone number already exists in the database
  Phones.findOne({
    where: { phoneNumber: phoneNumber }
  })
    .then(existingPhone => {
      if (existingPhone) {
        // If the phone number already exists, respond with an error
        return res.status(400).send({ message: "Phone number already exists." });
      } else {
        // If the phone number doesn't exist, create a new phone record
        Phones.create({
          type: type,
          phoneNumber: phoneNumber,
          contactId: contactId
        })
          .then(phone => {
            res.status(201).send(phone); // Respond with the created phone
          })
          .catch(err => {
            res.status(500).send({
              message: err.message || "Some error occurred while creating the phone."
            });
          });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || "Some error occurred while checking the phone number."
      });
    });
};


// Get all phones
exports.findAll = (req, res) => {
	 const contactId = req.params.contactId; // Extract the contactName from request params

  // Find a contact by contactName
  Phones.findAll({
    where: {
      contactId: contactId
    }
  })
    .then(phone => {
      if (!phone) {
        return res.status(404).send({ message: "No number." });
      }
      res.send(phone);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || `Error retrieving contact with contactId=${contactId}.`
      });
    });
};

//

exports.findOne = (req, res) => {
 const contactId = req.params.contactId;
 const phoneId = req.params.phoneId;
 
  Phones.findByPk(phoneId)
    .then(phone => {
      if (!phone) {
        return res.status(404).send({ message: "Phone number not found." });
      }
      res.send(phone);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || `Error retrieving contact with id=${phoneId}.`
      });
    });
};


// Get one phone by id


// Update one phone by id
exports.update = (req, res) => {
  //const contactId = req.params.contactId;
  const phoneId = req.params.phoneId;
  // Retrieve data from the request body
  const { contactId, type, phoneNumber } = req.body;
  
  Phones.findByPk(phoneId)
    .then(phone => {
      if (!phone) {
        return res.status(404).send({ message: "Phone number not found." });
      }
      
      // Update the contact's properties
      phone.contactId = contactId;
	  phone.type = type;
	  phone.phoneNumber = phoneNumber;
            
      // Save the updated contact to the database
      phone.save()
        .then(() => {
          res.send({ message: "Phone number was updated successfully." });
        })
        .catch(err => {
          res.status(500).send({
            message: err.message || "Some error occurred while updating the contact."
          });
        });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || `Error retrieving contact with id=${phoneId}.`
      });
    });
};

// Delete one phone by id
exports.delete = (req, res) => {
	const phoneId = req.params.phoneId;
  
  Phones.findByPk(phoneId)
    .then(phone => {
      if (!phone) {
        return res.status(404).send({ message: "Phone number not found." });
      }
      
      // Delete the contact from the database
      phone.destroy()
        .then(() => {
          res.send({ message: "Phone number was deleted successfully." });
        })
        .catch(err => {
          res.status(500).send({
            message: err.message || "Some error occurred while deleting the contact."
          });
        });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || `Error retrieving contact with id=${phoneId}.`
      });
    });
    
};