const db = require("../models");
const Phones = db.phones;
const Contacts = db.contacts;
const Op = db.Sequelize.Op;

// Calculate stats
exports.calculate = async (req, res) => {
  try {
    // Calculate total number of contacts
    const totalContacts = await Contacts.count();

	// Calculate total number of Phones
    const totalPhones = await Phones.count();


   // Find the newest contact timestamp
    const newestContact = await Contacts.findOne({
      order: [["createdAt", "DESC"]],
    });

    // Find the oldest contact timestamp
    const oldestContact = await Contacts.findOne({
      order: [["createdAt", "ASC"]],
    }); 

    // Send the response with the calculated data
    res.json({
      totalContacts,
	  totalPhones,
      newestTimestamp: newestContact.createdAt,
      oldestTimestamp: oldestContact.createdAt
    });
  } catch (error) {
    console.error("Error calculating stats:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
