const db = require("../models");
const Contacts = db.contacts;
const Phones = db.phones;
const Op = db.Sequelize.Op;

// Create contact
exports.create = (req, res) => {
  const { contactName } = req.body;

  // Validate the data, e.g., check if required fields are provided (contactName)

  // Create a new contact in the database with only the contactName field
  Contacts.create({
    contactName: contactName // Use "contactName" as the field name
  })
    .then(contact => {
      res.status(201).send(contact); // Respond with the created contact
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the contact."
      });
    });
};



// Get all contacts
exports.findAll = (req, res) => {
    Contacts.findAll()
	.then(data => {
		res.send(data);
	})
	.catch(err => {
		res.status(500).send({
			message: err.message || "Some error occured"
		});
	});
};

// Get one contact by id
exports.findOne = (req, res) => {
  const contactId = req.params.contactId;
  
  Contacts.findByPk(contactId)
    .then(contact => {
      if (!contact) {
        return res.status(404).send({ message: "Contact not found." });
      }
      res.send(contact);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || `Error retrieving contact with id=${contactId}.`
      });
    });
};


// Update one contact by id
exports.update = (req, res) => {
  const contactId = req.params.contactId;
  
  // Retrieve data from the request body
  const { contactName } = req.body;
  
  Contacts.findByPk(contactId)
    .then(contact => {
      if (!contact) {
        return res.status(404).send({ message: "Contact not found." });
      }
      
      // Update the contact's properties
      contact.contactName = contactName;
            
      // Save the updated contact to the database
      contact.save()
        .then(() => {
          res.send({ message: "Contact was updated successfully." });
        })
        .catch(err => {
          res.status(500).send({
            message: err.message || "Some error occurred while updating the contact."
          });
        });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || `Error retrieving contact with id=${contactId}.`
      });
    });
};


// Delete one contact by id
// Delete one contact by id
exports.delete = (req, res) => {
  const contactId = req.params.contactId;

  Contacts.findByPk(contactId)
    .then(contact => {
      if (!contact) {
        return res.status(404).send({ message: "Contact not found." });
      }

      // Use the 'include' option to also find and delete associated phone numbers
      Phones.destroy({
        where: { contactId: contact.id }
      })
        .then(() => {
          // After successfully deleting associated phone numbers, delete the contact
          contact.destroy()
            .then(() => {
              res.send({ message: "Contact and associated phone numbers were deleted successfully." });
            })
            .catch(err => {
              res.status(500).send({
                message: err.message || "Some error occurred while deleting the contact."
              });
            });
        })
        .catch(err => {
          res.status(500).send({
            message: err.message || "Some error occurred while deleting associated phone numbers."
          });
        });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || `Error retrieving contact with id=${contactId}.`
      });
    });
};

